"Bookworm" (c) 2008 Natasha Fernandez-Fountain, www.natashaisneat.com
--Personal, non-commercial use of this font is free.
--Commercial and for-profit purposes are prohibited without permission from me.
Contact me at natasha@natashaisneat.com
If you'd like to redistribute on another website, please send me an e-mail to let me know!